# SpigotMC - mathhulk Edition
Make mathhulk the SpigotMC god.

- Find SpigotMC - mathhulk Edition on the Chrome Web Store. ([link](https://chrome.google.com/webstore/detail/spigotmc-mathhulk-edition/bopjkeflcfflglmacbaniabkhclgkacc))
- Find SpigotMC - mathhulk Edition on SpigotMC. ([link](https://www.spigotmc.org/resources/mathhulk-extension.43487/))
